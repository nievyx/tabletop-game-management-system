"""
Run This:
python -m backend.app
"""

import uvicorn

if __name__ == "__main__":
    uvicorn.run("backend.app.main:app", reload=True)
